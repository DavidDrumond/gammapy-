   ___                                             
  / __|  __ _   _ __    _ __    __ _   _ __   _  _ 
 | (_ | / _` | | '  \  | '  \  / _` | | '_ \ | || |
  \___| \__,_| |_|_|_| |_|_|_| \__,_| | .__/  \_, |
                                      |_|     |__/ 

 _________________________________________________________________________

 Gammapy version: 0.1
 author : David Alvarenga Drumond 

 Gammapy is a open source python library develop to calculatate statistics 
 from spatial continuity functions.   

Spatial continuity functions are measures of spatial dependencies from variables distributed in space. 
Gammapy could calculate experimental functions and modelling based on gamV algorithm from GSLib. 
